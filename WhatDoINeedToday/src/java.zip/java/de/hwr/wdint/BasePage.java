/*
 * WicketExamplePage.java
 *
 * Created on 29. März 2011, 11:15
 */
 
package de.hwr.wdint;           

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.model.IModel;
import org.apache.wicket.markup.html.resources.StyleSheetReference;
import org.apache.wicket.util.string.Strings;

/** 
 *
 * @author juliusollesch
 * @version 
 */

public class BasePage extends WebPage {

    /**
     * Constructor
     */
    public BasePage() {
        this(null);
    }
    
    /**
     * Construct.
     * @param model
     */
    public BasePage(IModel model) {
        super(model);
        final String packageName = getClass().getPackage().getName();
        add(new HeaderPanel("mainNavigation", Strings.afterLast(packageName, '.')));
        add(new RSSPanel("rssPanel"));
        add(new StyleSheetReference("stylesheet", BasePage.class, "style.css"));
    }
}
