/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.hwr.wdint;

import com.sun.cnpi.rss.elements.Item;
import com.sun.cnpi.rss.elements.Rss;
import com.sun.cnpi.rss.parser.RssParser;
import com.sun.cnpi.rss.parser.RssParserException;
import com.sun.cnpi.rss.parser.RssParserFactory;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.AjaxFallbackLink;
import org.apache.wicket.ajax.markup.html.navigation.paging.AjaxPagingNavigator;
import org.apache.wicket.extensions.ajax.markup.html.AjaxEditableLabel;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.basic.MultiLineLabel;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.markup.repeater.data.DataView;
import org.apache.wicket.markup.repeater.data.ListDataProvider;
import org.apache.wicket.model.PropertyModel;

/**
 *
 * @author juliusollesch
 */
public final class RSSPanel extends Panel {

    private Location userLocation;
    //Title Label
    private String labelTitleText = "";

    public String getLabelText() {
        return labelTitleText;
    }

    public void setLabelText(String labelText) {
        this.labelTitleText = labelText;
    }
    AjaxEditableLabel title = new AjaxEditableLabel("title", new PropertyModel(this, "labelTitleText")) {

        @Override
        protected void onSubmit(AjaxRequestTarget target) {
            if (target != null) {
                super.onSubmit(target);
                if (labelTitleText != null) {
                    if (labelTitleText.equalsIgnoreCase("")) {
                        userLocation = new Location();
                    } else {
                        userLocation = new Location(labelTitleText);
                    }


                    labelTitleText = userLocation.urbanArea;

                    target.addComponent(title);
                    updateDataViewWithEvents(target);

                } else {
                    labelTitleText = userLocation.urbanArea;
                }
            }
        }

        {
            setOutputMarkupId(true);
        }
    };
    //Title Label
    //Data Container
    final WebMarkupContainer dataContainer = new WebMarkupContainer("dataContainer") {

        {
            setOutputMarkupId(true);
        }
    };
    //Data View
    private ArrayList list = new ArrayList();
    DataView dataView = new DataView("simple", new ListDataProvider(list), 5) {

        public void populateItem(final org.apache.wicket.markup.repeater.Item item) {
            final RSSEntry entry = (RSSEntry) item.getModelObject();
            item.add(new Label("id", entry.getTitle().toString()));
            item.add(new MultiLineLabel("description", entry.getDescription().toString()).setEscapeModelStrings(false));
        }

        {
            setOutputMarkupId(true);
        }
    };
    //Navigation Controller
    AjaxPagingNavigator pager = new AjaxPagingNavigator("navigator", dataView) {

        @Override
        protected void onAjaxEvent(AjaxRequestTarget target) {
            target.addComponent(dataContainer);
        }
    };

    public RSSPanel(String id) {
        super(id);
        this.setOutputMarkupId(true);
        try {
            userLocation = new Location();
            labelTitleText = userLocation.getUrbanArea();

            add(new AjaxFallbackLink("link1") {

                @Override
                public void onClick(AjaxRequestTarget target) {

                    // Ereignis behandeln
                    title.setDefaultModelObject("clicked");
                    // target ist null:    Regulärer Request, Seite wird neu geladen
                    // target ist gesetzt: Ajax-Request, Komponenten können aktualisiert werden
                    if (target != null) {
                        // Titel Label aktualisieren
                        labelTitleText = userLocation.getUrbanArea();
                        target.addComponent(title);
                        updateDataViewWithEvents(target);

                    }
                }
            });

            add(new AjaxFallbackLink("link2") {

                @Override
                public void onClick(AjaxRequestTarget target) {
                    // Ereignis behandeln
                    title.setDefaultModelObject("clicked");
                    // target ist null:    Regulärer Request, Seite wird neu geladen
                    // target ist gesetzt: Ajax-Request, Komponenten können aktualisiert werden
                    if (target != null) {
                        // Titel Label aktualisieren
                        labelTitleText = "Fernsehen";
                        target.addComponent(title);
                        try {
                            //Data View aktualisieren
                            list.clear();
                            list.addAll(readRSS(makeTVURL())); //aktualisert list
                            System.out.println("Liste mit: " + list.size());
                            //dataView.renderComponent();
                            target.addComponent(dataContainer);
                        } catch (MalformedURLException ex) {
                            Logger.getLogger(RSSPanel.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }
                }
            });

            add(title);
            dataContainer.add(dataView);
            dataContainer.add(pager);
            add(dataContainer);







        } catch (Exception ex) {
            Logger.getLogger(HeaderPanel.class.getName()).log(Level.SEVERE, null, ex);
            add(new Label("title", ex.toString()));
        }
    }

    private void updateDataViewWithEvents(AjaxRequestTarget target) {
        //Data View aktualisieren

        try {
            list.clear();
            list.addAll(readRSS(makePrinzKonzertURL(userLocation))); //aktualisert list
            list.addAll(readRSS(makePrinzPartyURL(userLocation))); //aktualisert list
            list.addAll(readRSS(makePrinzKulturURL(userLocation))); //aktualisert list

            target.addComponent(dataContainer);
        } catch (MalformedURLException ex) {
            Logger.getLogger(RSSPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private URL makePrinzKonzertURL(Location userLocation) throws MalformedURLException {
        String area = userLocation.urbanArea;
        area = area.replaceAll("ä", "ae");
        area = area.replaceAll("ü", "ue");
        area = area.replaceAll("ö", "oe");
        area = area.replaceAll("ß", "ss");
        area = area.toLowerCase();

        System.out.println("Area: " + area);
        return new URL("http://" + area + ".prinz.de/rss/konzert");

    }

    private URL makePrinzPartyURL(Location userLocation) throws MalformedURLException {
        String area = userLocation.urbanArea;
        area = area.replaceAll("ä", "ae");
        area = area.replaceAll("ü", "ue");
        area = area.replaceAll("ö", "oe");
        area = area.replaceAll("ß", "ss");
        area = area.toLowerCase();

        System.out.println("Area: " + area);
        return new URL("http://" + area + ".prinz.de/rss/party");

    }

    private URL makePrinzKulturURL(Location userLocation) throws MalformedURLException {
        String area = userLocation.urbanArea;
        area = area.replaceAll("ä", "ae");
        area = area.replaceAll("ü", "ue");
        area = area.replaceAll("ö", "oe");
        area = area.replaceAll("ß", "ss");
        area = area.toLowerCase();

        System.out.println("Area: " + area);
        return new URL("http://" + area + ".prinz.de/rss/kultur");

    }

    private URL makeTVURL() throws MalformedURLException {
        return new URL("http://www.tvprogramm24.com/rss.xml");
    }

    private ArrayList readRSS(URL feedURL) {
        String tag = "READRSS";
        String tv = "";
        //UNI Settings :-(

        //System.getProperties().put("http.proxyHost", "194.94.23.231");
        //System.getProperties().put("http.proxyPort", "80");

        //UNI Settings Ende
        ArrayList myList = new ArrayList();
        try {

            //Create Parser
            RssParser parser = RssParserFactory.createDefault();

            //Parse out URL
            URL url = feedURL;

            Rss rss = parser.parse(url);
            if (rss.getChannel() == null) {
                tv = "NULL";
                //return tv;
            }

            Collection items = rss.getChannel().getItems();
            if (items != null && !items.isEmpty()) {
                for (Iterator i = items.iterator(); i.hasNext();) {
                    Item item = (Item) i.next();
                    String itemTitle = item.getTitle().toString();
                    System.out.println("Original: " + item.getDescription().toString());
                    String itemDescription = item.getDescription().toString().replaceAll("(\r\n|\r|\n|\n\r)", "");//.replaceAll("<b[^<]+?>", "");
                    System.out.println("RegExed: " + itemDescription);
                    String itemLink = item.getLink().toString();
                    RSSEntry entry = new RSSEntry(itemTitle, itemDescription, itemLink);
                    myList.add(entry);
                }
            }


            //return tv;

        } catch (RssParserException e) {
            // TODO Auto-generated catch block
            tv = "RSSParserException";
            //return tv;
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            tv = "MalformedURLException";
            //return tv;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            tv = "IOException";
            //return tv;
        } finally {
            return myList;
        }
    }
}
