/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.hwr.wdint;

import java.io.Serializable;
import java.net.URL;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.wicket.RequestCycle;
import org.apache.wicket.protocol.http.WebRequest;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

/**
 *
 * @author juliusollesch
 */
public class Location implements Serializable {

    String userInput;
    String postalCode;
    String urbanArea;
    String latitude;
    String longitude;
    final String yahooAppID = "PCvCMCfV34EK39cA9nSF8xTLKsi_b_iYNcPOvjVVRf20M_OOxfevRC0duEU_7kvwwXBq_EJN3klw844mtFAHiNqFJC9F2Yo-";

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getUrbanArea() {
        return urbanArea;
    }

    public void setUrbanArea(String city) {
        double minDistance = Double.MAX_VALUE;
        String regionName = "";

        for (Regions c : Regions.values()) {
            double lat1 = c.getLatitude();
            double lon1 = c.getLongitude();

            double lat2 = Double.parseDouble(this.getLatitude());
            double lon2 = Double.parseDouble(this.getLongitude());

            double d = calculateDistance(lat1, lat2, lon1, lon2);
            if (d <= minDistance){
                minDistance = d;
                regionName = c.name();
            }
        }
        System.out.println("minDistance: " + minDistance + " Region: " + regionName);
        this.urbanArea = regionName;
    }

    public String getUserInput() {
        return userInput;
    }

    public void setUserInput(String userInput) {
        this.userInput = userInput;
    }

    public Location(String userInput) {
        getLocationInfoByUserInput(userInput);

    }

    public Location() {

        WebRequest wr = (WebRequest) RequestCycle.get().getRequest();
        String originatingIPAddress = wr.getHttpServletRequest().getRemoteHost();

        getLocationInfoByIP(originatingIPAddress);


    }

    private double calculateDistance(double lat1, double lat2, double lon1, double lon2) {
        int R = 6371; // Durchmesser der Erde in km

        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = R * c;
        return d;
    }

    private void getLocationInfoByUserInput(String input){
        try {

            // create a url object
            URL url = new URL("http://local.yahooapis.com/MapsService/V1/geocode?appid=" + yahooAppID + "&location=" + input);

            // create a urlconnection object

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(url.openStream());

            //normalize
            doc.getDocumentElement().normalize();

            NodeList cityNodes = doc.getElementsByTagName("City");
            if (cityNodes.getLength() > 0){
                this.setUserInput(cityNodes.item(0).getTextContent());
            }else{
                this.setUserInput("Not found");
            }
            NodeList latitudeNodes = doc.getElementsByTagName("Latitude");
            if (latitudeNodes.getLength() > 0){
                this.setLatitude(latitudeNodes.item(0).getTextContent());
            }else{
                this.setLatitude("0");
            }
            NodeList longitudeNodes = doc.getElementsByTagName("Longitude");
            if (longitudeNodes.getLength() > 0){
                this.setLongitude(longitudeNodes.item(0).getTextContent());
            }else{
                this.setLongitude("0");
            }
            this.setUrbanArea(this.getUserInput());


        } catch (Exception e) {
            this.setUserInput("Error: " + e.toString());
            this.setLatitude("0");
            this.setLongitude("0");
            this.setUrbanArea("Error");
            e.printStackTrace();
        }
    }

    private void getLocationInfoByIP(String theIP) {
        System.out.println("IP Adress = " + theIP);
        try {

            // create a url object
            URL url = new URL("http://www.geoplugin.net/xml.gp?ip=" + theIP);

            // create a urlconnection object

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(url.openStream());

            //normalize
            doc.getDocumentElement().normalize();



            NodeList cityNodes = doc.getElementsByTagName("geoplugin_city");
            if (cityNodes.getLength() > 0){
                this.setUserInput(cityNodes.item(0).getTextContent());
            }else{
                this.setUserInput("Not found");
            }
            NodeList latitudeNodes = doc.getElementsByTagName("geoplugin_latitude");
            if (latitudeNodes.getLength() > 0){
                this.setLatitude(latitudeNodes.item(0).getTextContent());
            }else{
                this.setLatitude("0");
            }
            NodeList longitudeNodes = doc.getElementsByTagName("geoplugin_longitude");
            if (longitudeNodes.getLength() > 0){
                this.setLongitude(longitudeNodes.item(0).getTextContent());
            }else{
                this.setLongitude("0");
            }
            this.setUrbanArea(this.getUserInput());


        } catch (Exception e) {
            this.setUserInput("Error: " + e.toString());
            this.setLatitude("0");
            this.setLongitude("0");
            this.setUrbanArea("Error");
            e.printStackTrace();
        }

    }
}
