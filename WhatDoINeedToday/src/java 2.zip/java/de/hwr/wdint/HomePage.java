/*
 * HomePage.java
 *
 * Created on 29. März 2011, 11:15
 */
 
package de.hwr.wdint;           

public class HomePage extends BasePage {

    public HomePage() {

    }
}
